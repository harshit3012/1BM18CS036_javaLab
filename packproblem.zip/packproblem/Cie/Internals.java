package Cie;

import java.util.*;
public class Internals{
	public int marks[];
	Scanner s = new Scanner(System.in);
	public Internals(){
		marks = new int[5];
	}
}
